/********************************************************************************
* program_memory.c: Contains function definitions and macro definitions for
*                   implementation of a 6 kB program memory, capable of storing
*                   up to 256 24-bit instructions. Since C doesn't support
*                   unsigned 24-bit integers (without using structs or unions),
*                   the program memory is set to 32 bits data width, but only
*                   24 bits are used.
********************************************************************************/
#include "program_memory.h"

/* Macro definitions: */
   #define main  4       
   #define main_loop  5
   #define setup 6        
   #define ISR_PCINT0 15
   #define ISR_PCINT0_end 19

   #define LED1     PORTA8
   #define BUTTON1  PORTA13  

/* Static functions: */
static inline uint64_t assemble(const uint16_t op_code,
                                const uint16_t op1,
                                const uint32_t op2);

/********************************************************************************
* data: Program memory with capacity for storing 256 instructions.
********************************************************************************/
static uint64_t data[PROGRAM_MEMORY_ADDRESS_WIDTH];

/********************************************************************************
* program_memory_write: Writes machine code to the program memory. This function
*                       should be called once when the program starts.
********************************************************************************/
void program_memory_write(void)
{
   static bool program_memory_initialized = false;
   if (program_memory_initialized) return;

   /********************************************************************************
   * RESET_vect: Reset vector and start address for the program. A jump is made
   *             to the main subroutine in order to start the program.
   ********************************************************************************/ 
   
   int p = 0;
   
   data[p]  = assemble(JMP, main, 0x00);
   data[++p]  = assemble(NOP, 0x00, 0x00);
   data[++p]  = assemble(JMP, ISR_PCINT0, 0x00);
   data[++p]  = assemble(NOP, 0x00, 0x00);

   data[++p]  = assemble(CALL, setup, 0x00);
   data[++p]  = assemble(JMP, main_loop, 0x00);

   data[++p]  = assemble(LDI, R16, (1 << LED1));
   data[++p]  = assemble(OUT, DDRA, R16);
   data[++p]  = assemble(LDI, R17, (1 << BUTTON1));
   data[++p]  = assemble(OUT, PORTA, R17);
   data[++p]  = assemble(SEI, 0x00, 0x00);
   data[++p]  = assemble(LDI, R24, (1 << PCIE0));
   data[++p]  = assemble(OUT, PCICR, R24);
   data[++p]  = assemble(OUT, PCMSK0, R17);
   data[++p]  = assemble(RET, 0x00, 0x00);

   data[++p]  = assemble(IN, R24, PINA);
   data[++p]  = assemble(ANDI, R24, (1 << BUTTON1));
   data[++p]  = assemble(BREQ, ISR_PCINT0_end, 0x00);
   data[++p]  = assemble(OUT, PINA, R16);
   data[++p]  = assemble(RETI, 0x00, 0x00);

   program_memory_initialized = true;
   return;
}

/********************************************************************************
* program_memory_read: Returns the instruction at specified address. If an
*                      invalid address is specified (should be impossible as
*                      long as the program memory address width isn't increased)
*                      no operation (0x00) is returned.
*
*                      - address: Address to instruction in program memory.
********************************************************************************/
uint64_t program_memory_read(const uint16_t address)
{
   if (address < PROGRAM_MEMORY_ADDRESS_WIDTH)
   {
      return data[address];
   }
   else
   {
      return 0x00;
   }
}

/********************************************************************************
* assemble: Returns instruction assembled to machine code.
* 
*           - op_code: OP code of the instruction.
*           - op1    : First operand (destination).
*           - op2    : Second operand (constant or read location).
********************************************************************************/
static inline uint64_t assemble(const uint16_t op_code,
                                const uint16_t op1,
                                const uint32_t op2)
{
   const uint64_t instruction = ((uint64_t)(op_code) << 48) | ((uint64_t)(op1) << 32) | op2; // OP-koden ska l�ggas p� bit 63 - 48, op1 fr�n 47 - 32, op = 31 - 0.
   return instruction;
}